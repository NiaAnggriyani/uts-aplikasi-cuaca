<html>
<body>
Aplikasi ini dapat prakiraan cuaca yang akan terjadi di Kota Semarang <br>
yang terdiri dari : 
<br>
<br>
1.	Mengetahui cuaca yang akan terjadi<br>
2.	Mengetahui suhu minimun dan suhu maksimun disuatu daerah<br>
3.	Mengetahui kecepatan angin dan juga arah angin<br>
</body>
</html>

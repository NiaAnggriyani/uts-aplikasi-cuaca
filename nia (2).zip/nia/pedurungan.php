<div>Pedurungan
</div>
<br>
<?php
  $json_string = file_get_contents("http://api.wunderground.com/api/14252955f15867ff/conditions/forecast/currenthurricane/q/IA/pedurungan.json");
  $parsed_json = json_decode($json_string);
  $weather = $parsed_json->{'current_observation'}->{'weather'};
  $f = $parsed_json->{'current_observation'}->{'temp_f'};
  $c = $parsed_json->{'current_observation'}->{'temp_c'};
  $ws = $parsed_json->currenthurricane[0]->Current->WindSpeed->Mph;
  $arah = $parsed_json->currenthurricane[0]->Current->Movement->Text;
  $icon   = $parsed_json->{'forecast'}->{"simpleforecast"}->forecastday[0]->{"icon"};
  echo " 
  Cuaca : ${weather} <img src='http://icons.wxug.com/i/c/k/" . $icon . ".gif'>
  Suhu Fahrenheit : ${f}<sup>o</sup> Fahrenheit<br>
  Suhu Celcius : ${c}<sup>o</sup> Celcius<br>
  Arah Angin : ${arah}<br>
  Kecepatan Angin : ${ws}";
?>
</div>